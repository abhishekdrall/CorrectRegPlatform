package com.regPlatform.regPlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegPlatfomApplicationTests {

	@Test
	void contextLoads() {
	}

}
