package com.regPlatform.regPlatform.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;

import com.regPlatform.regPlatform.dao.PatientRecordDao;
import com.regPlatform.regPlatform.entity.Appointment;
import com.regPlatform.regPlatform.entity.DoctorRecord;
import com.regPlatform.regPlatform.entity.PatientRecord;
import com.regPlatform.regPlatform.dao.AppointmentDao;
import com.regPlatform.regPlatform.dao.DoctorRecordDao;
@org.springframework.stereotype.Service
public class UserService implements Service {

	@Autowired
	public PatientRecordDao patientRecordDao;
	
	@Autowired
	public DoctorRecordDao doctorRecordDao;
	
	@Autowired
	public AppointmentDao appointmentDao;
	
	@Override
	public List<PatientRecord> getPatientRecord() {
		return patientRecordDao.findAll(); 
	}

	@Override
	public PatientRecord addPatiendRecord(PatientRecord patientRecord) {
		patientRecordDao.save(patientRecord);
		return patientRecord;
	}

	@Override
	public PatientRecord updatePatientRecord(PatientRecord patientRecord) {
		patientRecordDao.save(patientRecord);
		return patientRecord;
	}

	
	@Override
	public void deletePatientRecord(Integer parseInt) {
	@SuppressWarnings("deprecation")
	PatientRecord prEntity=patientRecordDao.getOne(parseInt);
	patientRecordDao.delete(prEntity);
		
	}

	@Override
	public List<DoctorRecord> getDoctorRecord() {
		return doctorRecordDao.findAll();
	}

	@Override
	public DoctorRecord addDoctorRecord(DoctorRecord doctorRecord) {
		doctorRecordDao.save(doctorRecord);
		return doctorRecord;
	}

	@Override
	public DoctorRecord updateDoctorRecord(DoctorRecord doctorRecord) {
		doctorRecordDao.save(doctorRecord);
		return doctorRecord;
	}
	@Override
	public void deleteDoctorRecord(Integer parseInt) {
		@SuppressWarnings("deprecation")
		DoctorRecord drEntity=doctorRecordDao.getOne(parseInt);
		doctorRecordDao.delete(drEntity);
	}

	@Override
	public Appointment setAppointment(Appointment appointments) {
		appointmentDao.save(appointments);
		return appointments;
	}

	@Override
	public List<Appointment> getSortedRecord(String field) {
		return appointmentDao.findAll(Sort.by(Sort.Direction.ASC , field));
		}


	
}
