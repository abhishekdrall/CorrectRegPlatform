package com.regPlatform.regPlatform.entity;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;




@Entity
public class DoctorRecord {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer docId;
	private String docName;
	private String docSpecialization;
	private String docEmail;
	

	@ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn
	private Appointment appointments;
	
	public Integer getDocId() {
		return docId;
	}
	public void setDocId(Integer docId) {
		this.docId = docId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocSpecialization() {
		return docSpecialization;
	}
	public void setDocSpecialization(String docSpecialization) {
		this.docSpecialization = docSpecialization;
	}
	public String getDocEmail() {
		return docEmail;
	}
	public void setDocEmail(String docEmail) {
		this.docEmail = docEmail;
	}
	public DoctorRecord() {
		super();
	}
	public Appointment getAppointments() {
		return appointments;
	}
	public void setAppointments(Appointment appointments) {
		this.appointments = appointments;
	}
	@Override
	public String toString() {
		return "DoctorRecord [docId=" + docId + ", docName=" + docName + ", docSpecialization=" + docSpecialization
				+ ", docEmail=" + docEmail +  "]";
	}
	
	
}
