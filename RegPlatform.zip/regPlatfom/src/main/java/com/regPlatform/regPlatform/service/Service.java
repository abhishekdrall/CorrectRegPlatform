package com.regPlatform.regPlatform.service;

import java.util.List;

import com.regPlatform.regPlatform.entity.Appointment;
import com.regPlatform.regPlatform.entity.DoctorRecord;
import com.regPlatform.regPlatform.entity.PatientRecord;

public interface Service {

	public List<PatientRecord> getPatientRecord();
	
	public PatientRecord addPatiendRecord(PatientRecord patientRecord);
	
	public PatientRecord updatePatientRecord(PatientRecord patientRecord);
	
	public void deletePatientRecord(Integer parseInt);

	public List<DoctorRecord> getDoctorRecord();
	
	public DoctorRecord addDoctorRecord(DoctorRecord doctorRecord);
	
	public DoctorRecord updateDoctorRecord(DoctorRecord doctorRecord);
	
	public void deleteDoctorRecord(Integer parseInt);

	public Appointment setAppointment(Appointment appointments);
	
	public List<Appointment> getSortedRecord(String field);
}
