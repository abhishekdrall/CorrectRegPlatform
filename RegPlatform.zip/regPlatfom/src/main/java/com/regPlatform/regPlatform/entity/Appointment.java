package com.regPlatform.regPlatform.entity;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Appointment {

	

	@Id
	@GeneratedValue( strategy= GenerationType.IDENTITY )
	private Integer code;
	private String speciality;
	
	private Date dateToVisit;
	private String status;

	@OneToMany(cascade = CascadeType.ALL)
	private List<DoctorRecord> doctorRecord= new ArrayList<>();

	@OneToMany(cascade = CascadeType.ALL)
	private List<PatientRecord> patientRecord = new ArrayList<>();

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public Date getDateToVisit() {
		return dateToVisit;
	}

	public void setDateToVisit(Date dateToVisit) {
		this.dateToVisit = dateToVisit;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<DoctorRecord> getDoctorRecord() {
		return doctorRecord;
	}

	public void setDoctorRecord(List<DoctorRecord> doctorRecord) {
		this.doctorRecord = doctorRecord;
	}

	public List<PatientRecord> getPatientRecord() {
		return patientRecord;
	}

	public void setPatientRecord(List<PatientRecord> patientRecord) {
		this.patientRecord = patientRecord;
	}

	public Appointment() {
		super();
	}

	@Override
	public String toString() {
		return "Appointment [code=" + code + ", speciality=" + speciality + ", dateToVisit=" + dateToVisit + ", status="
				+ status + ", doctorRecord=" + doctorRecord + ", patientRecord=" + patientRecord + "]";
	}
	

	
}
