package com.regPlatform.regPlatform.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.regPlatform.regPlatform.entity.DoctorRecord;

public interface DoctorRecordDao extends JpaRepository<DoctorRecord, Integer> {

}
